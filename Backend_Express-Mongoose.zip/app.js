const express = require('express');
const app = express();
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');

app.use(cors());
app.use(bodyParser.json());
let FruitSchema = require('./fruit.model');
mongoose.connect('mongodb+srv://justinelder:Mypass123@project1.vxblm.mongodb.net/NewDB?retryWrites=true&w=majority', { useUnifiedTopology: true });
const connection = mongoose.connection;
connection.once('open', function() {
    console.log('MONGOOSE CONNECTED TO MONGODB');
})


app.post('/add', function(req, res) {
    console.log('NEW FRUIT BODY', req.body);

    let newFruit = req.body;
    let fruitObj = new FruitSchema(newFruit);
    fruitObj.save().then(response => {
        console.log("Add: ", response);
    });
});
app.get('/find', function(req, res) {
    FruitSchema.find(function(err, response) {
        res.json(response);
    })
})

app.listen('3001', function(req, res) {
    console.log('Listening on 3001');
});