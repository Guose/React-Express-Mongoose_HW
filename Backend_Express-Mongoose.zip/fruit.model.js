const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let Fruit = new Schema({
    name: {
        type: String
    },
    color: {
        type: String
    },
    weight: {
        type: Number
    },
    delicious: {
        type: Boolean
    }
})

module.exports = mongoose.model('Fruit', Fruit);